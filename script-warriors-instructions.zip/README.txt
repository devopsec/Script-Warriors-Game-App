A Pen created at CodePen.io. You can find this one at http://codepen.io/devopsec/pen/VaoZEb.

 Instructions for the Script Warrior Game App