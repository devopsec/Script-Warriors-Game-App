A Pen created at CodePen.io. You can find this one at http://codepen.io/devopsec/pen/KzOPRb.

 The official webpage for the Script Warriors game app.